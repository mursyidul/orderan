<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Form Penawaran</h2>
        <ol class="breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li><a>Master Penawaran</a></li>
            <li class="active"><strong>Form Penawaran</strong></li>
        </ol>
    </div>
</div>

<div class="wrapper wrapper-content animated fadeIn">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Basic IN+ Panel</h5>
                </div>
                <div class="ibox-content" id="lineAreaChart">
                    <h2>This is standard IN+ Panel<br/></h2>
                </div>
            </div>
        </div>
    </div>
</div>